# Source screenshots

`mod6-counter-schematic.png` is a supplied screenshot of the Quartus
T-flip-flop counter schematic. `source-screenshots/` contains the uploaded
VHDL editor screenshots that were used to transcribe the Part B source.
Replace these with hardware demonstration pictures or waveform images
when those are available.
