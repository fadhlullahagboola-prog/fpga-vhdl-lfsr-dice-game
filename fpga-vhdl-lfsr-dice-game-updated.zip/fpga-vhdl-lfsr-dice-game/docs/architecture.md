# Architecture

## Part B: four-dice game

The top-level `lab_5b` accepts `CLOCK_50` and active-low `KEY(0)` and
instantiates `four_dice` and `scorer`.

```mermaid
flowchart TD
  CLOCK[CLOCK_50] --> TOP[lab_5b]
  KEY[KEY0 active low] --> TOP
  TOP --> FD[four_dice]
  FD --> LPM[4 x lpm_counter / widths 4, 5, 6, 7]
  LPM --> OD[4 x one_die]
  OD --> COUNT[counter_1to6]
  OD --> DECODE[die_decoder]
  DECODE --> HEX[HEX0, HEX1, HEX2, HEX3]
  OD --> SCORER[scorer]
  SCORER --> LED[LEDR2 four / LEDR1 three / LEDR0 two pairs]
```

| Module | Key behavior |
| --- | --- |
| `lab_5b` | Maps clock/button to dice module; die values to scorer; segments to HEX outputs; score to LEDs. |
| `four_dice` | Gates clock with the active-low roll button; supplies four independent LPM counter dividers. |
| `one_die` | Connects a six-state counter and display decoder. |
| `counter_1to6` | Original design was a T-flip-flop schematic. Included RTL is a behavioral substitute. |
| `die_decoder` | Selected-signal assignment for codes `001` through `110`, all other inputs blank. |
| `scorer` | Uses equality comparisons to detect four-kind, exactly three-kind, or two distinct pairs. |

**Clocking note:** The screenshot design gates the board clock with a button
and uses counter output bits as clocks. This is documented as implemented;
an FPGA production design would typically favor registered enables and
dedicated clocking resources instead of unqualified gated/derived clocks.

## Part A: parameterized LFSR

The assignment calls for an LFSR with a generic multiple-of-four width,
start/stop and reset controls, and hexadecimal output on the character LCD.
The RTL was not among the supplied screenshots, so no source has been
invented for this section.
