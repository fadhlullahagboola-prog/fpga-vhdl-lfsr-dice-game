# Hardware and pinout

The source uses signal names corresponding to the **Terasic DE2-115** board
shown in the supplied design screenshot.

| HDL port | Function |
| --- | --- |
| `CLOCK_50` | Input clock for the dice system |
| `KEY(0)` | Active-low pushbutton for rolling |
| `HEX0` | Die 1 seven-segment pattern |
| `HEX1` | Die 2 seven-segment pattern |
| `HEX2` | Die 3 seven-segment pattern |
| `HEX3` | Die 4 seven-segment pattern |
| `LEDR(2)` | Four-of-a-kind indicator |
| `LEDR(1)` | Three-of-a-kind indicator |
| `LEDR(0)` | Two-pairs indicator |

`HEX0`–`HEX3` use `std_logic_vector(0 to 6)` and active-low segment
patterns in the supplied decoder code. The **FPGA package pin assignments**
are not shown in the screenshots. Import the original Quartus `.qsf` or
the official board pin file for the exact installed device.
