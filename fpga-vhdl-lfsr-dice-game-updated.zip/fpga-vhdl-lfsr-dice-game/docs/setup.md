# Quartus setup

## Part B

1. Start a new Quartus Prime project targeting your actual Terasic DE2-115
   FPGA device. If you have a working project, open its original `.qpf` instead.
2. Add the six `.vhd` files under `part-b-dice-game/rtl/`.
3. Set `lab_5b` as the top-level entity.
4. The source uses `library lpm` / `lpm_counter`, provided in Quartus's
   vendor libraries.
5. Use the actual DE2-115 pin assignments from your existing `.qsf` file:
   `CLOCK_50`, `KEY[0]`, `HEX0[0..6]` through `HEX3[0..6]`, and
   `LEDR[0..2]`. **Do not substitute made-up FPGA package pin numbers.**
6. Compile and program the board as you would in your lab.

**Important:** If you import the original T-flip-flop counter `.bdf`, remove
`counter_1to6.vhd` from the project or rename/adjust the definition to
avoid two compiled entities with the same name.

## Part A

Add the original LFSR and Lab 4C LCD controller sources when available.
No Part A implementation is included in this archive yet.

## Version-control checklist

Keep `.vhd`, `.bdf`, `.qpf`, `.qsf`, `.sdc`, and useful documented images.
Avoid committing Quartus build databases, large program files, or generated
temporary artifacts.
