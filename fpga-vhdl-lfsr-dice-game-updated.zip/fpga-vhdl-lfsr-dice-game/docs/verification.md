# Verification guide

## Included self-checking testbenches

A scorer testbench covers the distinct combination classes plus permutations.
A decoder testbench covers the six valid die codes and both invalid codes.
A counter testbench checks the behavioral modulus-6 state sequence.
Run with a locally installed VHDL-2008-capable GHDL compiler:

```bash
bash part-b-dice-game/simulation/run_ghdl.sh
```

These testbenches were written for this repository and are **not captured
hardware test results**. The full `four_dice` design uses Intel LPM IP;
simulation of that module requires an appropriate vendor library or
adaptation.

## Hardware checks to document after opening the Quartus project

| Action | Expected outcome |
| --- | --- |
| Hold active-low `KEY(0)` pressed | Dice continue changing |
| Release `KEY(0)` | Dice values stop changing |
| Reach `3-3-3-3` | `LEDR(2)` asserted |
| Reach `2-2-2-5` | `LEDR(1)` asserted |
| Reach `1-4-1-4` | `LEDR(0)` asserted |
| Reach four different faces | All three scoring LEDs deasserted |

Add any actual compile logs, photos, and waveform images once they are
available; do not describe expected outcomes as observed results.
