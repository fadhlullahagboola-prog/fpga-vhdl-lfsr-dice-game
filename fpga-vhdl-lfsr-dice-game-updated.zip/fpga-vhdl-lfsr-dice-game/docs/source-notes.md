# Source inventory and provenance

This repository combines *code visibly supplied in screenshots* with
*supporting code written for the repository*. The distinction matters because
the screenshot of a schematic cannot be turned back into an editable Quartus
Block Diagram File (`.bdf`) with guaranteed fidelity.

| File | Origin | Notes |
| --- | --- | --- |
| `rtl/die_decoder.vhd` | Transcribed from source screenshot | Seven segment lookup for die values 1-6. |
| `rtl/one_die.vhd` | Transcribed from source screenshot | Instances of `counter_1to6` and `die_decoder`. |
| `rtl/four_dice.vhd` | Transcribed from multiple source screenshots | Uses Intel `lpm_counter` widths 4, 5, 6, 7 and active-low button enable. |
| `rtl/lab_5b.vhd` | Transcribed from two source screenshots | Top-level clock, button, HEX display, LED wiring. |
| `rtl/counter_1to6.vhd` | New behavioral *equivalent* | Follows intended 001–110 sequence; **not** a conversion of the schematic to source. |
| `rtl/scorer.vhd` | New implementation | Implements the assignment's four-kind, exactly-three-kind, two-pair rules; original scorer code not supplied. |
| `simulation/tb_scorer.vhd` | New repository testbench | Covers combination categories and permutations. |
| `simulation/tb_die_decoder.vhd` | New repository testbench | Covers all 3-bit input values. |
| `simulation/tb_counter_1to6.vhd` | New repository testbench | Checks the 001 through 110 state cycle of the behavioral stand-in. |

**Supplied image:** `media/mod6-counter-schematic.png` shows the original
Quartus schematic with T flip-flops and a NAND gate. The user-provided image
is preserved without redrawing. Screenshots of each code section are in
`media/source-screenshots/`.

**Still needed from the actual project:**

- Part A LFSR and LCD controller `.vhd` files.
- Editable modulus-6 counter `.bdf` if available.
- Original scorer `.vhd` if available.
- Intel Quartus `.qpf` and `.qsf` for exact device and board pin mapping.
- Optional timing constraints and compile reports or waveforms.

The code transcribed from images has been checked visually against the
portions shown in the uploads. Compiler and physical-board results are not
available from those screenshots alone.
