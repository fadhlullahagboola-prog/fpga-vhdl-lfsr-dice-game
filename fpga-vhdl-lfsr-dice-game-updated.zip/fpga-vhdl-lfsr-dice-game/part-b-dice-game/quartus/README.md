# Quartus project files

Place the original `.qpf`, `.qsf`, `.bdf`, and any `.sdc` files here.
The screenshot image is not a replacement for the editable `.bdf`.
The archive contains VHDL source but no board-specific `.qsf` yet.
