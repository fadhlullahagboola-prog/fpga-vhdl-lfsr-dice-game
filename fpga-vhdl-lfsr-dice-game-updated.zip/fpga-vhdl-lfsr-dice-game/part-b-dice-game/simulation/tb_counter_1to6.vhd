library ieee;
use ieee.std_logic_1164.all;
use std.env.all;

entity tb_counter_1to6 is
end tb_counter_1to6;

architecture test of tb_counter_1to6 is
    signal clock : std_logic := '0';
    signal q0, q1, q2 : std_logic;
begin
    dut: entity work.counter_1to6
        port map (clock => clock, q0 => q0, q1 => q1, q2 => q2);

    stimulus: process
        procedure tick_and_check(constant expected : in std_logic_vector(2 downto 0)) is
        begin
            clock <= '1';
            wait for 1 ns;
            assert (q2 & q1 & q0) = expected
                report "Unexpected modulus-6 counter state" severity error;
            clock <= '0';
            wait for 1 ns;
        end procedure;
    begin
        wait for 1 ns;
        assert (q2 & q1 & q0) = "001"
            report "Unexpected counter initial state" severity error;
        tick_and_check("010");
        tick_and_check("011");
        tick_and_check("100");
        tick_and_check("101");
        tick_and_check("110");
        tick_and_check("001");
        report "tb_counter_1to6: all checks passed" severity note;
        finish;
    end process;
end test;
