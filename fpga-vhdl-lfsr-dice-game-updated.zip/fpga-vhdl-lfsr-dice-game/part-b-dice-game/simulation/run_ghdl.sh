#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p work
# Requires GHDL with VHDL-2008 support. The entire Quartus design
# uses vendor lpm_counter components, so this script tests only
# the portable scorer, die_decoder, and counter_1to6 modules.
ghdl -a --std=08 --workdir=work ../rtl/scorer.vhd ../rtl/die_decoder.vhd ../rtl/counter_1to6.vhd
ghdl -a --std=08 --workdir=work tb_scorer.vhd tb_die_decoder.vhd tb_counter_1to6.vhd
ghdl -e --std=08 --workdir=work tb_scorer
ghdl -r --std=08 --workdir=work tb_scorer --assert-level=error
ghdl -e --std=08 --workdir=work tb_die_decoder
ghdl -r --std=08 --workdir=work tb_die_decoder --assert-level=error
ghdl -e --std=08 --workdir=work tb_counter_1to6
ghdl -r --std=08 --workdir=work tb_counter_1to6 --assert-level=error
