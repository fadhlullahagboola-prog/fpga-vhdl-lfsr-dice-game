library ieee;
use ieee.std_logic_1164.all;
use std.env.all;

entity tb_scorer is
end tb_scorer;

architecture test of tb_scorer is
    signal d1, d2, d3, d4 : std_logic_vector(2 downto 0) := "001";
    signal four_kind, three_kind, two_pairs : std_logic;
begin
    dut: entity work.scorer
        port map (
            die1 => d1, die2 => d2, die3 => d3, die4 => d4,
            four_kind => four_kind, three_kind => three_kind,
            two_pairs => two_pairs
        );

    stimulus: process
        procedure check(
            constant a, b, c, d : in std_logic_vector(2 downto 0);
            constant expected : in std_logic_vector(2 downto 0)
        ) is
        begin
            d1 <= a; d2 <= b; d3 <= c; d4 <= d;
            wait for 1 ns;
            assert (four_kind & three_kind & two_pairs) = expected
                report "Unexpected scorer result" severity error;
        end procedure;
    begin
        check("010", "010", "010", "010", "100"); -- four kind
        check("010", "010", "010", "101", "010"); -- triple 1
        check("010", "010", "101", "010", "010"); -- triple 2
        check("010", "101", "010", "010", "010"); -- triple 3
        check("101", "010", "010", "010", "010"); -- triple 4
        check("001", "001", "110", "110", "001"); -- two pair
        check("001", "110", "001", "110", "001"); -- two pair
        check("001", "110", "110", "001", "001"); -- two pair
        check("001", "010", "011", "100", "000"); -- all distinct
        check("001", "001", "011", "100", "000"); -- one pair
        report "tb_scorer: all checks passed" severity note;
        finish;
    end process;
end test;
