library ieee;
use ieee.std_logic_1164.all;
use std.env.all;

entity tb_die_decoder is
end tb_die_decoder;

architecture test of tb_die_decoder is
    signal c : std_logic_vector(2 downto 0) := "000";
    signal segments : std_logic_vector(0 to 6);
begin
    dut: entity work.die_decoder port map (c => c, segments => segments);
    stimulus: process
        procedure check(
            constant die : in std_logic_vector(2 downto 0);
            constant pattern : in std_logic_vector(0 to 6)
        ) is
        begin
            c <= die;
            wait for 1 ns;
            assert segments = pattern
                report "Unexpected die decoder segment pattern" severity error;
        end procedure;
    begin
        check("000", "1111111");
        check("001", "1111110");
        check("010", "0110111");
        check("011", "0110110");
        check("100", "1001001");
        check("101", "1001000");
        check("110", "0000001");
        check("111", "1111111");
        report "tb_die_decoder: all checks passed" severity note;
        finish;
    end process;
end test;
