# Simulation

`tb_scorer.vhd`, `tb_die_decoder.vhd`, and `tb_counter_1to6.vhd` are self-checking tests for the
portable modules. Run `bash run_ghdl.sh` with GHDL installed.
No test execution results are asserted here.
