-- Recreated from the assignment's scoring rules and top-level port map.
-- The user's original scorer RTL was not among the screenshots provided.
-- Indicators are mutually exclusive: exactly three-of-a-kind excludes four.

library ieee;
use ieee.std_logic_1164.all;

entity scorer is
    port (
        die1       : in  std_logic_vector(2 downto 0);
        die2       : in  std_logic_vector(2 downto 0);
        die3       : in  std_logic_vector(2 downto 0);
        die4       : in  std_logic_vector(2 downto 0);
        four_kind  : out std_logic;
        three_kind : out std_logic;
        two_pairs  : out std_logic
    );
end scorer;

architecture behavioral of scorer is
    signal all_same : std_logic;
    signal triple   : std_logic;
    signal pairs    : std_logic;
begin
    all_same <= '1' when (die1 = die2 and die2 = die3 and die3 = die4) else '0';

    triple <= '1' when (
        (die1 = die2 and die2 = die3) or
        (die1 = die2 and die2 = die4) or
        (die1 = die3 and die3 = die4) or
        (die2 = die3 and die3 = die4)
    ) else '0';

    pairs <= '1' when (
        (die1 = die2 and die3 = die4 and die1 /= die3) or
        (die1 = die3 and die2 = die4 and die1 /= die2) or
        (die1 = die4 and die2 = die3 and die1 /= die2)
    ) else '0';

    four_kind  <= all_same;
    three_kind <= triple and not all_same;
    two_pairs  <= pairs;
end behavioral;
