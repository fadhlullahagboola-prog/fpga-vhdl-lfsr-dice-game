library ieee;
use ieee.std_logic_1164.all;

entity die_decoder is
    port (
        c        : in  std_logic_vector(2 downto 0);
        segments : out std_logic_vector(0 to 6)
    );
end die_decoder;

architecture behavior of die_decoder is
begin
    with c select
        segments <= "1111110" when "001",  -- Die 1
                    "0110111" when "010",  -- Die 2
                    "0110110" when "011",  -- Die 3
                    "1001001" when "100",  -- Die 4
                    "1001000" when "101",  -- Die 5
                    "0000001" when "110",  -- Die 6
                    "1111111" when others;
end behavior;
