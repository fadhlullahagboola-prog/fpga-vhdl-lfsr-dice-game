# Part B RTL files

`lab_5b.vhd` is the top-level entity. The `four_dice.vhd`, `one_die.vhd`,
and `die_decoder.vhd` files were transcribed from provided screenshots.

The original T-flip-flop counter was a schematic; `counter_1to6.vhd` is a
newly written behavioral equivalent for source-based reuse. `scorer.vhd`
was written from the provided combination specifications because its
original source wasn't shown.

See [`../../docs/source-notes.md`](../../docs/source-notes.md).
