library ieee;
use ieee.std_logic_1164.all;

entity lab_5b is
    port (
        CLOCK_50 : in  std_logic;
        KEY      : in  std_logic_vector(0 downto 0);

        HEX0 : out std_logic_vector(0 to 6);
        HEX1 : out std_logic_vector(0 to 6);
        HEX2 : out std_logic_vector(0 to 6);
        HEX3 : out std_logic_vector(0 to 6);

        LEDR : out std_logic_vector(2 downto 0)
    );
end lab_5b;

architecture structural of lab_5b is
    component four_dice
        port (
            clk : in std_logic;
            PB  : in std_logic;

            die1 : out std_logic_vector(2 downto 0);
            die2 : out std_logic_vector(2 downto 0);
            die3 : out std_logic_vector(2 downto 0);
            die4 : out std_logic_vector(2 downto 0);

            seg1 : out std_logic_vector(0 to 6);
            seg2 : out std_logic_vector(0 to 6);
            seg3 : out std_logic_vector(0 to 6);
            seg4 : out std_logic_vector(0 to 6)
        );
    end component;

    component scorer
        port (
            die1 : in std_logic_vector(2 downto 0);
            die2 : in std_logic_vector(2 downto 0);
            die3 : in std_logic_vector(2 downto 0);
            die4 : in std_logic_vector(2 downto 0);

            four_kind  : out std_logic;
            three_kind : out std_logic;
            two_pairs  : out std_logic
        );
    end component;

    signal d1, d2, d3, d4 : std_logic_vector(2 downto 0);
begin
    -- Four dice
    DICE_GAME: four_dice
        port map (
            clk => CLOCK_50,
            PB  => KEY(0),

            die1 => d1,
            die2 => d2,
            die3 => d3,
            die4 => d4,

            seg1 => HEX0,
            seg2 => HEX1,
            seg3 => HEX2,
            seg4 => HEX3
        );

    -- Score comparison
    SCORE: scorer
        port map (
            die1 => d1,
            die2 => d2,
            die3 => d3,
            die4 => d4,

            four_kind  => LEDR(2),
            three_kind => LEDR(1),
            two_pairs  => LEDR(0)
        );
end structural;
