-- Behavioral equivalent provided to make the project portable in source form.
-- The original Lab 5B counter was entered as a T-flip-flop Quartus
-- schematic; its screenshot is in media/mod6-counter-schematic.png.
-- Replace this file with the generated VHDL or original .bdf for exact
-- preservation of the schematic implementation.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity counter_1to6 is
    port (
        clock : in  std_logic;
        q0    : out std_logic;
        q1    : out std_logic;
        q2    : out std_logic
    );
end counter_1to6;

architecture behavioral_equivalent of counter_1to6 is
    signal count : unsigned(2 downto 0) := "001";
begin
    process (clock)
    begin
        if rising_edge(clock) then
            if count = "110" then
                count <= "001";
            else
                count <= count + 1;
            end if;
        end if;
    end process;

    q0 <= count(0);
    q1 <= count(1);
    q2 <= count(2);
end behavioral_equivalent;
