library ieee;
use ieee.std_logic_1164.all;

entity one_die is
    port (
        pulse     : in  std_logic;
        die_value : out std_logic_vector(2 downto 0);
        segments  : out std_logic_vector(0 to 6)
    );
end one_die;

architecture structural of one_die is
    component counter_1to6
        port (
            clock : in  std_logic;
            q0    : out std_logic;
            q1    : out std_logic;
            q2    : out std_logic
        );
    end component;

    component die_decoder
        port (
            c        : in  std_logic_vector(2 downto 0);
            segments : out std_logic_vector(0 to 6)
        );
    end component;

    signal s : std_logic_vector(2 downto 0);
begin
    C1: counter_1to6
        port map (
            clock => pulse,
            q0 => s(0),
            q1 => s(1),
            q2 => s(2)
        );

    D1: die_decoder
        port map (
            c => s,
            segments => segments
        );

    die_value <= s;
end structural;
