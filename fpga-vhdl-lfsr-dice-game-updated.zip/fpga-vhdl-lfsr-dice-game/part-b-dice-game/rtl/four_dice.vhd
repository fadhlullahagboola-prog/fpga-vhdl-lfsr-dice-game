library ieee;
use ieee.std_logic_1164.all;

library lpm;
use lpm.lpm_components.all;

entity four_dice is
    port (
        clk : in std_logic;
        PB  : in std_logic;

        die1 : out std_logic_vector(2 downto 0);
        die2 : out std_logic_vector(2 downto 0);
        die3 : out std_logic_vector(2 downto 0);
        die4 : out std_logic_vector(2 downto 0);

        seg1 : out std_logic_vector(0 to 6);
        seg2 : out std_logic_vector(0 to 6);
        seg3 : out std_logic_vector(0 to 6);
        seg4 : out std_logic_vector(0 to 6)
    );
end four_dice;

architecture structural of four_dice is
    component one_die
        port (
            pulse     : in  std_logic;
            die_value : out std_logic_vector(2 downto 0);
            segments  : out std_logic_vector(0 to 6)
        );
    end component;

    signal roll_clock : std_logic;
    signal count1 : std_logic_vector(3 downto 0);
    signal count2 : std_logic_vector(4 downto 0);
    signal count3 : std_logic_vector(5 downto 0);
    signal count4 : std_logic_vector(6 downto 0);
begin
    -- DE2-115 pushbutton is active-low.
    -- Press PB to enable rolling.
    roll_clock <= clk and (not PB);

    -- Die 1: 4-bit delay counter
    delay1: lpm_counter
        generic map (
            lpm_width     => 4,
            lpm_direction => "UP"
        )
        port map (
            clock => roll_clock,
            q     => count1
        );

    dice1: one_die
        port map (
            pulse     => count1(3),
            die_value => die1,
            segments  => seg1
        );

    -- Die 2: 5-bit delay counter
    delay2: lpm_counter
        generic map (
            lpm_width     => 5,
            lpm_direction => "UP"
        )
        port map (
            clock => roll_clock,
            q     => count2
        );

    dice2: one_die
        port map (
            pulse     => count2(4),
            die_value => die2,
            segments  => seg2
        );

    -- Die 3: 6-bit delay counter
    delay3: lpm_counter
        generic map (
            lpm_width     => 6,
            lpm_direction => "UP"
        )
        port map (
            clock => roll_clock,
            q     => count3
        );

    dice3: one_die
        port map (
            pulse     => count3(5),
            die_value => die3,
            segments  => seg3
        );

    -- Die 4: 7-bit delay counter
    delay4: lpm_counter
        generic map (
            lpm_width     => 7,
            lpm_direction => "UP"
        )
        port map (
            clock => roll_clock,
            q     => count4
        );

    dice4: one_die
        port map (
            pulse     => count4(6),
            die_value => die4,
            segments  => seg4
        );
end structural;
