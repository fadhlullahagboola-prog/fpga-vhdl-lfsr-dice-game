# Part A LFSR RTL

This section needs the original parameterized LFSR implementation plus the
LCD display controller from Lab 4C. The provided material for this section
was the assignment instructions, not the source code.
