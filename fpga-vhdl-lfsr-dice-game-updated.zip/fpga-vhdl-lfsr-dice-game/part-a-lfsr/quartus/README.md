# Part A Quartus project

Add the original Part A `.qpf`, `.qsf`, and timing/board configuration
files when available.
