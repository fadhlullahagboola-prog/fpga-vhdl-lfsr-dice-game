# Part A simulation

Add the original LFSR testbench and waveform results when available.
